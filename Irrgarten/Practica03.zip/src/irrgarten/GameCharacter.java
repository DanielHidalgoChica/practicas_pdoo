package irrgarten;

/**
 *
 * @author luisvaldivieso
 */
public enum GameCharacter {
    PLAYER,MONSTER
}
