package irrgarten;

/**
 *  Directions enum type
 * @author luisvaldivieso
 */
public enum Directions {
    LEFT,RIGHT,UP,DOWN
}
