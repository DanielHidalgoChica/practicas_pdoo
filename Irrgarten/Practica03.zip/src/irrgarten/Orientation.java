package irrgarten;

/**
 *  Orientation enum type
 * @author luisvaldivieso
 */
public enum Orientation {
    VERTICAL, HORIZONTAL
}
